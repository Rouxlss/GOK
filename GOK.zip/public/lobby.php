<?php 
    include './src/lobby/lobby.view.php';
?>